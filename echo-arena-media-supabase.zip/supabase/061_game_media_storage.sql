-- Echo Arena
-- 061_game_media_storage.sql
-- Storage e campos administráveis de mídia para heróis e equipamentos

begin;

-- ============================================================
-- 1. CAMPOS DE MÍDIA DOS HERÓIS
-- ============================================================

alter table public.heroes
add column if not exists image_url text,
add column if not exists card_image_url text,
add column if not exists gif_url text,
add column if not exists image_fit text not null default 'contain',
add column if not exists image_position text not null default '50% 50%',
add column if not exists image_scale numeric(6,3) not null default 1,
add column if not exists image_offset_x integer not null default 0,
add column if not exists image_offset_y integer not null default 0,
add column if not exists display_order integer not null default 0;

-- ============================================================
-- 2. CAMPOS DE MÍDIA DOS EQUIPAMENTOS
-- ============================================================

alter table public.equipments
add column if not exists image_url text,
add column if not exists image_fit text not null default 'contain',
add column if not exists image_position text not null default '50% 50%',
add column if not exists image_scale numeric(6,3) not null default 1,
add column if not exists image_offset_x integer not null default 0,
add column if not exists image_offset_y integer not null default 0,
add column if not exists display_order integer not null default 0;

-- ============================================================
-- 3. FUNÇÃO DE ADMINISTRADOR BASEADA EM ROLES
-- ============================================================

create or replace function public.current_user_is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles p
    join public.roles r on r.id = p.role_id
    where p.id = auth.uid()
      and r.name = 'admin'
  );
$$;

grant execute on function public.current_user_is_admin()
to anon, authenticated;

-- ============================================================
-- 4. BUCKET PÚBLICO PARA MÍDIAS DO JOGO
-- ============================================================

insert into storage.buckets (
  id,
  name,
  public,
  file_size_limit,
  allowed_mime_types
)
values (
  'game-media',
  'game-media',
  true,
  26214400,
  array[
    'image/png',
    'image/jpeg',
    'image/gif',
    'image/webp'
  ]::text[]
)
on conflict (id) do update
set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- ============================================================
-- 5. POLÍTICAS DO STORAGE
-- ============================================================

drop policy if exists "game_media_public_read"
on storage.objects;

drop policy if exists "game_media_admin_insert"
on storage.objects;

drop policy if exists "game_media_admin_update"
on storage.objects;

drop policy if exists "game_media_admin_delete"
on storage.objects;

create policy "game_media_public_read"
on storage.objects
for select
to anon, authenticated
using (bucket_id = 'game-media');

create policy "game_media_admin_insert"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'game-media'
  and public.current_user_is_admin()
);

create policy "game_media_admin_update"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'game-media'
  and public.current_user_is_admin()
)
with check (
  bucket_id = 'game-media'
  and public.current_user_is_admin()
);

create policy "game_media_admin_delete"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'game-media'
  and public.current_user_is_admin()
);

-- ============================================================
-- 6. ÍNDICES
-- ============================================================

create index if not exists idx_heroes_display_order
on public.heroes(display_order, name);

create index if not exists idx_equipments_display_order
on public.equipments(display_order, name);

commit;
