ECHO ARENA — MÍDIA NO SUPABASE

1. Execute `061_game_media_storage.sql` no SQL Editor do Supabase.

2. No painel administrativo, envie:
   - GIF principal do herói para `heroes/gifs`
   - imagem da carta para `heroes/cards`
   - imagem do equipamento para `equipments`

3. Use `admin-media.js` no painel admin:
   `import { uploadGameMedia, saveHeroMedia, saveEquipmentMedia } from './admin-media.js';`

4. Substitua o seu `criar-build.html` por `criar-build-supabase.html`
   e renomeie para `criar-build.html`.

5. Mantenha `js/supabase.js` no projeto.

O frontend deixa de usar `img/Slayer.gif` e passa a buscar `gif_url`,
`card_image_url` e `image_url` diretamente das tabelas do Supabase.
