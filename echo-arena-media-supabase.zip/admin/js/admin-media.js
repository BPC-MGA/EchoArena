import { supabase } from '../../js/supabase.js';

const BUCKET = 'game-media';
const ALLOWED_TYPES = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
const MAX_SIZE = 25 * 1024 * 1024;

function sanitizeFileName(name) {
  return name
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, '-')
    .replace(/-+/g, '-');
}

export async function uploadGameMedia(file, folder) {
  if (!file) throw new Error('Selecione um arquivo.');
  if (!ALLOWED_TYPES.includes(file.type)) {
    throw new Error('Formato permitido: PNG, JPG, GIF ou WEBP.');
  }
  if (file.size > MAX_SIZE) {
    throw new Error('O arquivo deve ter no máximo 25 MB.');
  }

  const safeName = sanitizeFileName(file.name);
  const path = `${folder}/${crypto.randomUUID()}-${safeName}`;

  const { error: uploadError } = await supabase.storage
    .from(BUCKET)
    .upload(path, file, {
      cacheControl: '3600',
      upsert: false,
      contentType: file.type
    });

  if (uploadError) throw uploadError;

  const { data } = supabase.storage
    .from(BUCKET)
    .getPublicUrl(path);

  return {
    path,
    publicUrl: data.publicUrl
  };
}

export async function deleteGameMedia(path) {
  if (!path) return;
  const { error } = await supabase.storage
    .from(BUCKET)
    .remove([path]);

  if (error) throw error;
}

export async function saveHeroMedia(heroId, values) {
  const { data, error } = await supabase
    .from('heroes')
    .update({
      image_url: values.imageUrl || null,
      card_image_url: values.cardImageUrl || null,
      gif_url: values.gifUrl || null,
      image_fit: values.fit || 'contain',
      image_position: values.position || '50% 50%',
      image_scale: Number(values.scale ?? 1),
      image_offset_x: Number(values.offsetX ?? 0),
      image_offset_y: Number(values.offsetY ?? 0)
    })
    .eq('id', heroId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function saveEquipmentMedia(equipmentId, values) {
  const { data, error } = await supabase
    .from('equipments')
    .update({
      image_url: values.imageUrl || null,
      image_fit: values.fit || 'contain',
      image_position: values.position || '50% 50%',
      image_scale: Number(values.scale ?? 1),
      image_offset_x: Number(values.offsetX ?? 0),
      image_offset_y: Number(values.offsetY ?? 0)
    })
    .eq('id', equipmentId)
    .select()
    .single();

  if (error) throw error;
  return data;
}
